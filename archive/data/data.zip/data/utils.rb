require 'date'
#require 'active_support/core_ext'
require 'rinruby'

@prices = {} # "2017-05-27T15:32:20+00:00" => 12314.5
@grants = Hash.new(0) # "2017-05-27T15:32:20+00:00" => 15000000
@sends = Hash.new(0) # "2017-05-27T15:32:20+00:00" => 30000000
@lowest_time = "2016-12-25T00:00:00+00:00"
@highest_time = "2018-01-11T08:00:00+00:00"
#populateData

def makedot
	dotfile = ["digraph G {"]
	File.open('bitfinexGrant2').each do |line|
		if m = line.match(/(\w{32})1KYiKJEfdJtap9QX2v9BXJMpz2SfU4pgZw/)
			dotfile.push("#{m.captures[0]} -> 1KYiKJEfdJtap9QX2v9BXJMpz2SfU4pgZw")
		end

		if m = line.match(/1KYiKJEfdJtap9QX2v9BXJMpz2SfU4pgZw(\w{32})/)
			dotfile.push("1KYiKJEfdJtap9QX2v9BXJMpz2SfU4pgZw -> #{m.captures[0]}")
		end
	end
	dotfile.push("}")
	File.open("dotfile.dot", "w") do |f|
	 	f.puts(dotfile)
	end
end

def benfords
	sign = 0
	num_flag = false
	denom_flag = false
	sizes = []
	#wallet = "1KYiKJEfdJtap9QX2v9BXJMpz2SfU4pgZw"
	#File.open('BitfinexAddy').each do |line|
	#kwallet = 3GyeFJmQynJWd8DeACm4cdEnZcckAtrfc / 'kraken'
	
	File.open('bitfinexGrant2').each do |line|
		#puts line
		#puts "*******"


		if num_flag && line != "\n"
			#puts line
			num_flag = false
			sizes.push(line.chomp.to_i)
			denom_flag = true
			#puts current#, sign, line.chomp.to_i
			sign = 0
			next
		end

		if denom_flag 
			if line.match('TetherUS')
				#puts line
			else
				sizes.pop ###ignores non Tether transactions
			end
			denom_flag = false
		end
		

		if line.match(/\w{32}1KYiKJEfdJtap9QX2v9BXJMpz2SfU4pgZw/)
			sign = -1
			num_flag = true
		end

		if line.match(/1KYiKJEfdJtap9QX2v9BXJMpz2SfU4pgZw\w{32}/)
			sign = 1
			num_flag = true
		end
	end
	return arrayToLeadingCount(sizes)
end

def arrayToLeadingCount(array)
	counter = Hash.new(0)
	array.each do |a|
		counter[a.to_s[0].to_i] += 1
	end
	leadingCount = (1..9).to_a.map{|n| counter[n]}
	return leadingCount
end


def walletSize
	current = 97814842

	sign = 0
	num_flag = false
	wallet = "1KYiKJEfdJtap9QX2v9BXJMpz2SfU4pgZw"
	File.open('BitfinexAddy').each do |line|
		if num_flag && line != "\n"
			num_flag = false
			current = current + (sign * line.chomp.to_i)
			puts current#, sign, line.chomp.to_i
			sign = 0
		end

		if line.match(/\w{32}1KYiKJEfdJtap9QX2v9BXJMpz2SfU4pgZw/)
			sign = -1
			num_flag = true
		end

		if line.match(/1KYiKJEfdJtap9QX2v9BXJMpz2SfU4pgZw\w{32}/)
			sign = 1
			num_flag = true
		end
	end
end

def getInterval
	file = File.open("coindeskYear.csv")
	array = []
	file.each do |line|

	    line_a = line.chomp.split(",")
	   	puts line_a[0]
	   	unless line_a[0] == 'datetime'
			array.push([DateTime.strptime(line_a[0], '%Y-%m-%d %H:%M:%S'), line_a[1].to_f])
		end
	end
	puts array[0]
end

def transformPrints
	file = File.open("prints.csv")
	array = ["grant_time,transfer_time,amount"]
	file.each do |line|

	    line_a = line.chomp.split(",")
	   	unless line_a[1] == 'grant_time'
	   		#puts line_a[1]
	   		parsed_grant = DateTime.strptime(line_a[1], "%m/%d/%Y %H:%M:%S %p")
	   		formatted_grant = parsed_grant.strftime('%Y-%m-%d %H:%M:%S')
	   		parsed_transfer = DateTime.strptime(line_a[2], "%m/%d/%Y %H:%M:%S %p")
	   		formatted_transfer = parsed_transfer.strftime('%Y-%m-%d %H:%M:%S')
	   		
			array.push([formatted_grant, formatted_transfer, line_a[0].to_i].join(","))
		end
	end
	File.open("printsFormatted.csv", "w+") do |f|
  		f.puts(array)
  	end
end

def getBitfinexInfo
	str = client.get_content 'https://api.bitfinex.com/v2/book/tBTCUSD/P1'
	a[25..49].collect {|x|  -x[0]*x[2]}.reduce(:+) #move up cost instant
	a[0..24].collect {|x|  x[0]*x[2]}.reduce(:+) #move down cost instant
end

def populateData
	file = File.open("printsFormatted.csv")
	file.each do |line|
		a = line.chomp.split(",")
		unless a[0] == 'grant_time'
			grant = DateTime.parse(a[0]).to_s
			transfer = DateTime.parse(a[1]).to_s
			amount = a[2].to_i
			@grants[grant] += amount
			@sends[transfer] += amount
		end
	end
	file.close

	price_file = File.open("year.csv")
	price_file.each do |line|
		a = line.chomp.gsub('"', '').split(",")
		unless a[0] == "datetime"
			tick = DateTime.parse(a[0]).to_s
			@prices[tick] = a[1].to_f
		end
	end
end

def getPercentChange(start, hours, before)
	start_time = DateTime.parse(start)
	if before
		rounded_start_time = start_time.beginning_of_hour
		earlier_time = rounded_start_time - hours.hours
		ratio = @prices[rounded_start_time.to_s] / @prices[earlier_time.to_s]
		return ((ratio - 1) * 100)
	else
		rounded_start_time = start_time.beginning_of_hour + 1.hour
		later_time = rounded_start_time + hours.hours
		ratio = @prices[later_time.to_s] / @prices[rounded_start_time.to_s]
		return ((ratio - 1) * 100)
	end
end

def getSpacedDistribution(interval)
	lower = DateTime.parse(@lowest_time)
	upper = lower + interval.hours
	percentages = []
	while upper.to_s != @highest_time
		ratio = (@prices[upper.to_s] / @prices[lower.to_s])
		percentages.push(((ratio - 1) * 100))
		lower += 1.hour
		upper += 1.hour
	end
	return percentages
end

def getSample(hours, before)
	if before
		@grants.keys.map{|x| getPercentChange(x, hours, true)}.sort
	else
		@sends.keys.map{|x| getPercentChange(x, hours, false)}.sort
	end
end



